// supabase.ts — Supabase client for ClassCard
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://iunoahajcaaxmttdpgem.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_rUgPdjSjCcQfaEY0uc1mZw_vKqC_itL';

export const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export type Profile = {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'teacher' | 'student';
  student_id?: string;
};

export type Student = {
  id: string;
  name: string;
  teacher_id: string;
  auth_user_id?: string;
  login_email?: string;
  created_at: string;
};

export type Card = {
  id: string;
  student_id: string;
  teacher_id: string;
  rarity: 'common' | 'silver' | 'gold-rare' | 'prismatic';
  card_name: string;
  hp: number;
  type: string;
  description: string;
  stat1_name: string;
  stat1_val: number;
  stat2_name: string;
  stat2_val: number;
  stat3_name: string;
  stat3_val: number;
  move1_name: string;
  move1_dmg: number;
  move2_name: string;
  move2_dmg: number;
  image_url: string;
  card_source?: 'generated' | 'built';
  created_at: string;
  students?: { name: string };
};
