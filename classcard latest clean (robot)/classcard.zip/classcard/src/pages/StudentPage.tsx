import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import PokeCard from '../components/PokeCard';
import BuiltCard from '../components/BuiltCard';
import { Dashboard } from '../lib/dashboard';
import { sb } from '../lib/supabase';
import type { Session } from '../lib/auth';
import type { Card } from '../lib/supabase';

type WeeklyProject = {
  id: string;
  teacher_id: string;
  title: string;
  task: string;
  char_hint: string | null;
  card_data: Partial<Card> | null;
  week_label: string | null;
};

/* ─────────────────────────────────────────────
   Helpers
───────────────────────────────────────────── */
const RARITY_ICONS: Record<string, string> = {
  common: '☆', silver: '✦', 'gold-rare': '★', prismatic: '✦✦',
};

function rarityScore(cards: Card[]) {
  return cards.reduce((sum, c) => {
    const pts = { common: 50, silver: 150, 'gold-rare': 300, prismatic: 600 } as Record<string, number>;
    return sum + (pts[c.rarity] ?? 50);
  }, 0);
}

function rarityCardStyle(rarity: string): React.CSSProperties {
  switch (rarity) {
    case 'gold-rare':
      return { background: 'linear-gradient(145deg, #fff8e1 0%, #ffe082 60%, #ffd54f 100%)', border: '2px solid #ffca28' };
    case 'silver':
      return { background: 'linear-gradient(145deg, #f5f5f5 0%, #e0e0e0 60%, #bdbdbd 100%)', border: '2px solid #b0bec5' };
    case 'prismatic':
      return { background: 'linear-gradient(135deg, #fce4ec, #e8eaf6, #e0f7fa, #f3e5f5, #fce4ec)', border: '2px solid #ce93d8' };
    default:
      return { background: 'linear-gradient(145deg, #fafafa 0%, #f0f4ff 100%)', border: '2px solid #b3c2e8' };
  }
}

/* 4 colour themes — click knob to cycle through them */
const COLOR_THEMES = [
  { light: '#e3f2fd', mid: '#90caf9', dark: '#42a5f5', glow: 'rgba(66,165,245,0.35)', label: 'Sky',       wave: '#42a5f5', waveShadow: 'rgba(66,165,245,0.8)'  },
  { light: '#fce4ec', mid: '#f8bbd0', dark: '#f48fb1', glow: 'rgba(244,143,177,0.35)', label: 'Bubblegum', wave: '#f06292', waveShadow: 'rgba(240,98,146,0.8)'  },
  { light: '#f1f8e9', mid: '#c5e1a5', dark: '#8bc34a', glow: 'rgba(139,195,74,0.35)', label: 'Minty',     wave: '#66bb6a', waveShadow: 'rgba(102,187,106,0.8)' },
  { light: '#fffde7', mid: '#fff176', dark: '#fdd835', glow: 'rgba(253,216,53,0.35)',  label: 'Lemon',     wave: '#fdd835', waveShadow: 'rgba(253,216,53,0.8)'  },
] as const;

function knobToRobotColor(k: number) {
  return COLOR_THEMES[k % COLOR_THEMES.length];
}

/* ─────────────────────────────────────────────
   Waveform canvas component
───────────────────────────────────────────── */
function Waveform({ colorIndex }: { colorIndex: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const colorRef = useRef(colorIndex);
  colorRef.current = colorIndex;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    function draw(ts: number) {
      const W = canvas!.width;
      const H = canvas!.height;
      ctx.clearRect(0, 0, W, H);
      const theme = COLOR_THEMES[colorRef.current % COLOR_THEMES.length];

      // Grid lines tinted to current color
      ctx.strokeStyle = theme.wave + '18';
      ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
      for (let y = 0; y < H; y += 15) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

      // Glow waveform — color matches theme
      const idx = colorRef.current;
      const speed = 0.0015 + (idx / 4) * 0.003;
      const amp = 18 + (idx / 4) * 20;
      const freq = 1 + (idx / 4) * 3;

      ctx.shadowColor = theme.wave;
      ctx.shadowBlur = 14;
      ctx.strokeStyle = theme.waveShadow;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let px = 0; px < W; px++) {
        const t = (px / W) * Math.PI * 2 * freq + ts * speed;
        const spike = Math.exp(-((px / W - 0.4) ** 2) * 20) * amp * 1.8;
        const y = H / 2 + Math.sin(t) * amp * 0.4 + spike * Math.sin(t * 3);
        px === 0 ? ctx.moveTo(px, y) : ctx.lineTo(px, y);
      }
      ctx.stroke();
      ctx.shadowBlur = 0;

      animRef.current = requestAnimationFrame(draw);
    }
    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={400}
      height={120}
      style={{ width: '100%', height: '100%', display: 'block' }}
    />
  );
}

/* ─────────────────────────────────────────────
   Robot avatar
───────────────────────────────────────────── */
type RobotColor = ReturnType<typeof knobToRobotColor>;

function RobotAvatar({ level, xp, xpMax, color, facePixels }: { level: number; xp: number; xpMax: number; color: RobotColor; facePixels: string[] | null }) {
  const { light, mid, dark, glow, label } = color;
  return (
    <div style={{ position: 'relative', width: 180, flexShrink: 0 }}>
      <style>{`
        @keyframes robotBounce {
          0%,100% { transform: translateY(0); }
          50%      { transform: translateY(-6px); }
        }
        @keyframes eyeBlink {
          0%,90%,100% { transform: scaleY(1); }
          95%          { transform: scaleY(0.08); }
        }
        .robot-body { animation: robotBounce 3s ease-in-out infinite; }
        .robot-eye  { animation: eyeBlink 4s ease-in-out infinite; }
      `}</style>

      <div className="robot-body" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
        {/* Antenna */}
        <div style={{ width: 3, height: 22, background: `linear-gradient(180deg,${mid},${dark})`, borderRadius: 4, marginBottom: -4, transition: 'background 0.6s ease' }} />
        <div style={{ width: 10, height: 10, borderRadius: '50%', background: dark, boxShadow: `0 0 10px ${dark}`, transition: 'background 0.6s ease, box-shadow 0.6s ease' }} />

        {/* Head */}
        <div style={{ width: 120, height: 90, background: `linear-gradient(145deg,${light},${mid})`, borderRadius: 24, position: 'relative', boxShadow: `0 8px 24px ${glow}, inset 0 2px 4px rgba(255,255,255,0.6)`, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background 0.6s ease, box-shadow 0.6s ease' }}>
          {/* Face screen */}
          <div style={{ width: 80, height: 52, background: '#0d1117', borderRadius: 12, overflow: 'hidden', boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {facePixels ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(20, 1fr)', gap: 0, width: 70, height: 44 }}>
                {facePixels.map((c, i) => (
                  <div key={i} style={{ background: c === 'on' ? color.wave : '#0d1117' }} />
                ))}
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, width: '100%', height: '100%' }}>
                {[0, 1].map(i => (
                  <div key={i} className="robot-eye" style={{ width: 18, height: 22, borderRadius: '50%', background: 'radial-gradient(circle at 40% 35%, #c8f0ff, #6dd5fa)', boxShadow: '0 0 12px rgba(100,210,255,0.7)', transformOrigin: 'center' }} />
                ))}
              </div>
            )}
          </div>
          {/* Ear nubs */}
          {[-1, 1].map(s => (
            <div key={s} style={{ position: 'absolute', top: '50%', [s === -1 ? 'left' : 'right']: -8, transform: 'translateY(-50%)', width: 10, height: 28, background: `linear-gradient(145deg,${mid},${dark})`, borderRadius: 6, transition: 'background 0.6s ease' }} />
          ))}
        </div>

        {/* Neck */}
        <div style={{ width: 28, height: 12, background: `linear-gradient(180deg,${mid},${dark})`, borderRadius: 6, transition: 'background 0.6s ease' }} />

        {/* Body */}
        <div style={{ width: 130, height: 110, background: `linear-gradient(145deg,${light},${mid})`, borderRadius: 28, position: 'relative', boxShadow: `0 10px 30px ${glow}, inset 0 2px 4px rgba(255,255,255,0.6)`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'background 0.6s ease, box-shadow 0.6s ease' }}>
          {/* Arm nubs */}
          {[-1, 1].map(s => (
            <div key={s} style={{ position: 'absolute', top: 20, [s === -1 ? 'left' : 'right']: -14, width: 18, height: 60, background: `linear-gradient(180deg,${mid},${dark})`, borderRadius: 12, transition: 'background 0.6s ease' }} />
          ))}
          {/* Chest screen */}
          <div style={{ width: 88, height: 58, background: '#0d1117', borderRadius: 14, boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.5)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <span style={{ color: '#a8e6ff', fontSize: '0.75rem', fontWeight: 800, letterSpacing: 1 }}>LVL {level}</span>
            <span style={{ color: 'rgba(168,230,255,0.6)', fontSize: '0.6rem' }}>{xp} XP</span>
            <div style={{ width: 60, height: 5, background: 'rgba(255,255,255,0.1)', borderRadius: 10, overflow: 'hidden' }}>
              <div style={{ width: `${Math.min(100, (xp / xpMax) * 100)}%`, height: '100%', background: 'linear-gradient(90deg,#64b5f6,#ab47bc)', borderRadius: 10 }} />
            </div>
          </div>
        </div>

        {/* Legs */}
        <div style={{ display: 'flex', gap: 16 }}>
          {[0, 1].map(i => (
            <div key={i} style={{ width: 32, height: 38, background: `linear-gradient(180deg,${mid},${dark})`, borderRadius: '12px 12px 16px 16px', boxShadow: `0 4px 12px ${glow}`, transition: 'background 0.6s ease' }} />
          ))}
        </div>
      </div>

      {/* Color label badge */}
      <div style={{ textAlign: 'center', marginTop: 6 }}>
        <span style={{ fontSize: '0.55rem', fontWeight: 800, letterSpacing: '0.1em', color: dark, textTransform: 'uppercase', opacity: 0.8, transition: 'color 0.6s ease' }}>{label}</span>
      </div>
    </div>
  );
}


/* ─────────────────────────────────────────────
   Pixel face editor (20×14 grid)
───────────────────────────────────────────── */
const GRID_COLS = 20;
const GRID_ROWS = 14;
const EMPTY_GRID = () => Array(GRID_COLS * GRID_ROWS).fill('off');

function PixelEditor({ waveColor, onSend, onReset }: {
  waveColor: string;
  onSend: (pixels: string[]) => void;
  onReset: () => void;
}) {
  const [grid, setGrid] = useState<string[]>(EMPTY_GRID);
  // Track double-tap for touch: { index, timer }
  const lastTap = useRef<{ idx: number; time: number } | null>(null);

  const colorPixel = (i: number) => {
    setGrid(g => { const n = [...g]; n[i] = 'on'; return n; });
  };
  const erasePixel = (i: number) => {
    setGrid(g => { const n = [...g]; n[i] = 'off'; return n; });
  };

  // Mouse: single click = color, double click = erase
  const handleClick = (i: number) => {
    colorPixel(i);
  };
  const handleDoubleClick = (i: number) => {
    erasePixel(i);
  };

  // Touch: single tap = color, double tap = erase
  const handleTouchEnd = (e: React.TouchEvent, i: number) => {
    e.preventDefault(); // stop ghost click
    const now = Date.now();
    if (lastTap.current && lastTap.current.idx === i && now - lastTap.current.time < 350) {
      // double tap — erase
      erasePixel(i);
      lastTap.current = null;
    } else {
      // single tap — color
      colorPixel(i);
      lastTap.current = { idx: i, time: now };
    }
  };

  const clearGrid = () => setGrid(EMPTY_GRID());

  return (
    <div style={{ marginTop: 12, background: 'linear-gradient(145deg,rgba(255,255,255,0.85),rgba(252,240,255,0.9))', borderRadius: 20, padding: '14px 16px', border: '1.5px solid rgba(255,255,255,0.8)', boxShadow: '0 4px 16px rgba(180,120,220,0.08)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <span style={{ fontSize: '0.6rem', fontWeight: 800, letterSpacing: '0.14em', color: '#9090c0', textTransform: 'uppercase' }}>
          Draw your face
        </span>
        <span style={{ fontSize: '0.55rem', color: '#b0b8cc', fontStyle: 'italic' }}>
          tap = draw · double-tap = erase
        </span>
      </div>

      {/* Pixel grid */}
      <div
        style={{ display: 'grid', gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`, gap: 1.5, background: '#0d1117', borderRadius: 10, padding: 7, userSelect: 'none', touchAction: 'none', boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.5)' }}
      >
        {grid.map((cell, i) => (
          <div
            key={i}
            onClick={() => handleClick(i)}
            onDoubleClick={() => handleDoubleClick(i)}
            onTouchEnd={(e) => handleTouchEnd(e, i)}
            style={{
              width: '100%',
              aspectRatio: '1',
              borderRadius: 1,
              background: cell === 'on' ? waveColor : 'rgba(255,255,255,0.04)',
              border: cell === 'on' ? 'none' : '1px solid rgba(255,255,255,0.05)',
              cursor: 'crosshair',
              transition: 'background 0.06s',
              boxShadow: cell === 'on' ? `0 0 3px ${waveColor}88` : 'none',
            }}
          />
        ))}
      </div>

      {/* Buttons */}
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <button
          onClick={clearGrid}
          style={{ flex: 1, padding: '6px 0', fontSize: '0.65rem', fontWeight: 700, background: 'rgba(180,160,220,0.1)', border: '1px solid rgba(180,160,220,0.25)', borderRadius: 10, color: '#9090c0', cursor: 'pointer', letterSpacing: '0.06em' }}
        >
          Clear
        </button>
        <button
          onClick={onReset}
          style={{ flex: 1, padding: '6px 0', fontSize: '0.65rem', fontWeight: 700, background: 'rgba(100,180,255,0.1)', border: '1px solid rgba(100,180,255,0.25)', borderRadius: 10, color: '#6090c0', cursor: 'pointer', letterSpacing: '0.06em' }}
        >
          Reset eyes
        </button>
        <button
          onClick={() => onSend([...grid])}
          style={{ flex: 1, padding: '6px 0', fontSize: '0.65rem', fontWeight: 800, background: `${waveColor}22`, border: `1px solid ${waveColor}66`, borderRadius: 10, color: waveColor, cursor: 'pointer', letterSpacing: '0.06em', transition: 'background 0.2s' }}
        >
          Send ✦
        </button>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Signal Panel (center hero)
───────────────────────────────────────────── */
function SignalPanel({ knob, onKnobChange }: { knob: number; onKnobChange: (v: number) => void }) {
  const theme = COLOR_THEMES[knob % COLOR_THEMES.length];
  // 4 positions evenly spaced around the dial: -135°, -45°, 45°, 135°
  const knobAngle = -135 + (knob % COLOR_THEMES.length) * 90;

  const handleClick = () => {
    onKnobChange((knob + 1) % COLOR_THEMES.length);
  };

  return (
    <div style={{ flex: 1, background: 'linear-gradient(145deg,rgba(255,255,255,0.85),rgba(252,240,245,0.9))', borderRadius: 28, padding: '20px 24px', boxShadow: '0 8px 32px rgba(220,140,180,0.12), inset 0 2px 0 rgba(255,255,255,0.9), inset 0 -2px 8px rgba(200,150,180,0.08)', backdropFilter: 'blur(8px)', border: '1.5px solid rgba(255,255,255,0.8)' }}>
      {/* Label */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: theme.wave, boxShadow: `0 0 8px ${theme.wave}`, transition: 'background 0.3s, box-shadow 0.3s' }} />
        <span style={{ fontSize: '0.7rem', fontWeight: 800, letterSpacing: '0.18em', color: '#8090b0', textTransform: 'uppercase' }}>ClassCard Signal</span>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: theme.wave, boxShadow: `0 0 8px ${theme.wave}`, transition: 'background 0.3s, box-shadow 0.3s' }} />
      </div>

      <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
        {/* Waveform screen */}
        <div style={{ flex: 1, height: 120, background: '#0a0e1a', borderRadius: 16, overflow: 'hidden', boxShadow: 'inset 0 2px 12px rgba(0,0,0,0.6), 0 2px 8px rgba(100,80,140,0.15)', border: '1px solid rgba(80,60,100,0.3)' }}>
          <Waveform colorIndex={knob % COLOR_THEMES.length} />
        </div>

        {/* Knob — click to cycle */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
          <div
            onClick={handleClick}
            style={{ width: 80, height: 80, borderRadius: '50%', background: 'linear-gradient(145deg,#fff,#e8eef8)', boxShadow: '4px 4px 12px rgba(180,190,220,0.5), -3px -3px 8px rgba(255,255,255,0.9), inset 0 1px 3px rgba(255,255,255,0.8)', cursor: 'pointer', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', userSelect: 'none', border: `2px solid ${theme.wave}44`, transition: 'border-color 0.3s, box-shadow 0.3s' }}
          >
            {/* Knob ring */}
            <div style={{ width: 68, height: 68, borderRadius: '50%', border: `2px solid ${theme.wave}55`, position: 'absolute', transition: 'border-color 0.3s' }} />
            {/* Indicator dot — snaps to one of 4 positions */}
            <div style={{ position: 'absolute', width: 8, height: 8, borderRadius: '50%', background: theme.wave, top: 8, left: '50%', marginLeft: -4, transform: `rotate(${knobAngle}deg)`, transformOrigin: '4px 32px', boxShadow: `0 0 6px ${theme.wave}`, transition: 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1), background 0.3s, box-shadow 0.3s' }} />
          </div>
          <div style={{ fontSize: '0.65rem', fontWeight: 800, letterSpacing: '0.12em', color: theme.dark, textTransform: 'uppercase', transition: 'color 0.3s' }}>{theme.label}</div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Stats panel
───────────────────────────────────────────── */
function StatsPanel({ total, rarityScoreVal, onSignOut, studentName }: { total: number; rarityScoreVal: number; onSignOut: () => void; studentName: string }) {
  const nextRewardXp = 250;
  const currentXp = (rarityScoreVal % 500);
  const pct = Math.min(100, (currentXp / nextRewardXp) * 100);

  return (
    <div style={{ width: 200, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {/* User badge */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'rgba(255,255,255,0.7)', borderRadius: 20, padding: '10px 14px', border: '1.5px solid rgba(255,255,255,0.9)', boxShadow: '0 4px 12px rgba(200,160,200,0.1)', backdropFilter: 'blur(8px)' }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#fce4ec,#e8eaf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', boxShadow: '0 2px 8px rgba(200,140,180,0.2)', flexShrink: 0 }}>🤖</div>
        <span style={{ fontSize: '0.65rem', fontWeight: 800, letterSpacing: '0.06em', color: '#5060a0', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{studentName.toUpperCase()}</span>
        <button onClick={onSignOut} style={{ fontSize: '0.55rem', color: '#9090c0', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>▾</button>
      </div>

      {/* Stats card */}
      <div style={{ flex: 1, background: 'rgba(255,255,255,0.7)', borderRadius: 24, padding: '20px 18px', border: '1.5px solid rgba(255,255,255,0.9)', boxShadow: '0 8px 24px rgba(200,160,220,0.1)', backdropFilter: 'blur(8px)', display: 'flex', flexDirection: 'column', gap: 20 }}>
        {[
          { label: 'TOTAL CARDS', value: total },
          { label: 'RARITY SCORE', value: rarityScoreVal.toLocaleString() },
        ].map(row => (
          <div key={row.label}>
            <div style={{ fontSize: '0.58rem', fontWeight: 700, letterSpacing: '0.12em', color: '#a0a8c8', textTransform: 'uppercase', marginBottom: 4 }}>{row.label}</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 900, color: '#3040a0', lineHeight: 1 }}>{row.value}</div>
          </div>
        ))}

        {/* Next reward */}
        <div>
          <div style={{ fontSize: '0.58rem', fontWeight: 700, letterSpacing: '0.12em', color: '#a0a8c8', textTransform: 'uppercase', marginBottom: 4 }}>NEXT REWARD</div>
          <div style={{ fontSize: '1.3rem', fontWeight: 900, color: '#3040a0', marginBottom: 8 }}>{nextRewardXp - currentXp} XP</div>
          <div style={{ height: 8, background: 'rgba(100,120,220,0.12)', borderRadius: 10, overflow: 'hidden' }}>
            <div style={{ width: `${pct}%`, height: '100%', background: 'linear-gradient(90deg,#64b5f6,#9c27b0)', borderRadius: 10, transition: 'width 0.8s ease' }} />
          </div>
        </div>
      </div>

      {/* Battle button */}
      <a href="/arena" style={{ textDecoration: 'none' }}>
        <div
          style={{ background: 'linear-gradient(135deg,#f06292,#ab47bc,#64b5f6)', borderRadius: 18, padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 6px 20px rgba(180,80,180,0.3)', cursor: 'pointer', transition: 'all 0.2s' }}
          onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1.03)'; (e.currentTarget as HTMLDivElement).style.boxShadow = '0 8px 28px rgba(180,80,180,0.5)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1)'; (e.currentTarget as HTMLDivElement).style.boxShadow = '0 6px 20px rgba(180,80,180,0.3)'; }}
        >
          <span style={{ fontSize: '0.75rem', fontWeight: 900, letterSpacing: '0.1em', color: '#fff', textTransform: 'uppercase' }}>Battle Arena</span>
          <span style={{ fontSize: '1rem' }}>⚔️</span>
        </div>
      </a>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Card item in carousel
───────────────────────────────────────────── */
function CardItem({ card, onClick }: { card: Card; onClick: () => void }) {
  const [hovered, setHovered] = useState(false);
  const stars = { common: 1, silver: 2, 'gold-rare': 3, prismatic: 4 }[card.rarity] ?? 1;

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        flexShrink: 0,
        width: 180,
        borderRadius: 22,
        padding: '0 0 14px',
        cursor: 'pointer',
        transform: hovered ? 'translateY(-8px) scale(1.03)' : 'translateY(0) scale(1)',
        transition: 'transform 0.25s cubic-bezier(0.34,1.56,0.64,1)',
        boxShadow: hovered
          ? '0 16px 40px rgba(180,120,220,0.25)'
          : '0 4px 16px rgba(180,120,220,0.12)',
        overflow: 'hidden',
        ...rarityCardStyle(card.rarity),
      }}
    >
      {/* Stars */}
      <div style={{ padding: '10px 12px 4px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: '0.75rem', color: card.rarity === 'common' ? '#9090b0' : card.rarity === 'silver' ? '#7090a0' : card.rarity === 'gold-rare' ? '#c08000' : '#9040c0' }}>
          {RARITY_ICONS[card.rarity]}
        </span>
        <span style={{ fontSize: '0.6rem', color: 'rgba(0,0,0,0.3)' }}>
          {'★'.repeat(stars)}{'☆'.repeat(4 - stars)}
        </span>
      </div>

      {/* Image */}
      <div style={{ width: '100%', height: 120, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
        {card.image_url
          ? <img src={card.image_url} alt={card.card_name} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
          : <div style={{ fontSize: '2.5rem', opacity: 0.3 }}>🃏</div>
        }
      </div>

      {/* Name */}
      <div style={{ padding: '6px 12px 0', textAlign: 'center' }}>
        <div style={{ fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.1em', color: '#3040a0', textTransform: 'uppercase', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {card.card_name}
        </div>
        {card.rarity === 'prismatic' && (
          <div style={{ fontSize: '0.5rem', color: '#9040c0', marginTop: 2 }}>✦ PRISMATIC ✦</div>
        )}
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Card Carousel
───────────────────────────────────────────── */
function CardCarousel({ cards, onCardClick }: { cards: Card[]; onCardClick: (c: Card) => void }) {
  const [page, setPage] = useState(0);
  const perPage = 6;
  const totalPages = Math.ceil(cards.length / perPage);
  const visible = cards.slice(page * perPage, page * perPage + perPage);

  return (
    <div style={{ background: 'rgba(255,255,255,0.55)', borderRadius: 28, padding: '20px 24px', border: '1.5px solid rgba(255,255,255,0.85)', boxShadow: '0 4px 20px rgba(200,160,220,0.08)', backdropFilter: 'blur(8px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: '#64b5f6', fontSize: '0.7rem' }}>✦</span>
          <span style={{ fontSize: '0.72rem', fontWeight: 800, letterSpacing: '0.12em', color: '#5060a0', textTransform: 'uppercase' }}>Your Cards</span>
        </div>
        {totalPages > 1 && (
          <button
            onClick={() => setPage(p => (p + 1) % totalPages)}
            style={{ width: 28, height: 28, borderRadius: '50%', background: 'rgba(100,120,220,0.1)', border: '1px solid rgba(100,120,220,0.2)', color: '#6070c0', fontSize: '0.7rem', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >▶</button>
        )}
      </div>

      {/* Cards row */}
      {cards.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 20px', color: '#a0a8c8', fontSize: '0.85rem' }}>
          <div style={{ fontSize: '2rem', marginBottom: 12, opacity: 0.3 }}>🃏</div>
          No cards yet — keep up the great work!
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingBottom: 4 }}>
          {visible.map(card => (
            <CardItem key={card.id} card={card} onClick={() => onCardClick(card)} />
          ))}
        </div>
      )}

      {/* Pagination dots */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 16 }}>
          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              style={{ width: i === page ? 20 : 8, height: 8, borderRadius: 10, background: i === page ? 'linear-gradient(90deg,#f06292,#64b5f6)' : 'rgba(160,170,210,0.35)', border: 'none', cursor: 'pointer', transition: 'all 0.3s', padding: 0 }}
            />
          ))}
          <span style={{ color: '#a0a8c8', fontSize: '0.6rem', display: 'flex', alignItems: 'center', marginLeft: 4 }}>▶</span>
        </div>
      )}
    </div>
  );
}


/* ─────────────────────────────────────────────
   Weekly Project banner + modal
───────────────────────────────────────────── */
type WeeklyProjectProps = { project: WeeklyProject; onClose: () => void };

function WeeklyProjectModal({ project, onClose }: WeeklyProjectProps) {
  const card = project.card_data as Card | null;
  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, background: 'rgba(100,80,140,0.3)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '20px' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ background: 'linear-gradient(145deg,rgba(255,255,255,0.97),rgba(248,240,252,0.98))', borderRadius: 32, padding: '32px', maxWidth: 740, width: '90vw', maxHeight: '88vh', overflowY: 'auto', boxShadow: '0 24px 64px rgba(160,80,200,0.18)', border: '2px solid rgba(255,255,255,0.9)', position: 'relative' }}
      >
        <button onClick={onClose} style={{ position: 'absolute', top: 16, right: 16, width: 32, height: 32, borderRadius: '50%', background: 'rgba(180,160,220,0.12)', border: 'none', fontSize: '1rem', cursor: 'pointer', color: '#9090c0' }}>✕</button>

        {/* Header */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <span style={{ fontSize: '1rem' }}>📋</span>
            <span style={{ fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.14em', color: '#9090c0', textTransform: 'uppercase' }}>Weekly Project</span>
            {project.week_label && (
              <span style={{ fontSize: '0.6rem', color: '#b0b8d0', marginLeft: 4 }}>· {project.week_label}</span>
            )}
          </div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 900, color: '#3040a0', margin: 0 }}>{project.title}</h2>
        </div>

        {/* Two-column layout: task left, card right */}
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <colgroup>
            <col style={{ width: '55%' }} />
            <col style={{ width: '45%' }} />
          </colgroup>
          <tbody>
            <tr>
              {/* Left: task description */}
              <td style={{ verticalAlign: 'top', paddingRight: 28 }}>
                <div style={{ fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.12em', color: '#a0a8c8', textTransform: 'uppercase', marginBottom: 10 }}>What you need to do</div>
                <p style={{ fontSize: '0.95rem', color: '#4050a0', lineHeight: 1.7, margin: 0, whiteSpace: 'pre-wrap' }}>{project.task}</p>

                {/* Earn card hint */}
                <div style={{ marginTop: 24, padding: '14px 18px', background: 'rgba(100,180,100,0.08)', border: '1.5px solid rgba(100,180,100,0.2)', borderRadius: 16 }}>
                  <div style={{ fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.1em', color: '#4a9a60', textTransform: 'uppercase', marginBottom: 4 }}>✦ Earn a card</div>
                  <p style={{ fontSize: '0.82rem', color: '#5a7060', margin: 0, lineHeight: 1.5 }}>
                    Complete this project and your teacher will award you a card — the better the effort, the rarer the card!
                  </p>
                </div>
              </td>

              {/* Right: card preview */}
              <td style={{ verticalAlign: 'top', textAlign: 'center' }}>
                <div style={{ fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.12em', color: '#a0a8c8', textTransform: 'uppercase', marginBottom: 10 }}>Card you could earn</div>
                {card && card.card_name ? (
                  <div style={{ display: 'inline-block', transform: 'scale(0.8)', transformOrigin: 'top center' }}>
                    {card.card_source === 'built'
                      ? <BuiltCard card={card as Card} size="full" />
                      : <PokeCard card={card as Card} size="full" />
                    }
                  </div>
                ) : (
                  <div style={{ padding: '40px 20px', background: 'rgba(100,120,220,0.05)', border: '2px dashed rgba(100,120,220,0.2)', borderRadius: 20, color: '#a0a8c8' }}>
                    <div style={{ fontSize: '2.5rem', marginBottom: 10, opacity: 0.4 }}>🃏</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700 }}>Card coming soon</div>
                    <div style={{ fontSize: '0.65rem', marginTop: 4, opacity: 0.7 }}>Your teacher is preparing it</div>
                  </div>
                )}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function WeeklyProjectBanner({ project, onClick }: { project: WeeklyProject; onClick: () => void }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered
          ? 'linear-gradient(135deg,rgba(255,248,220,0.95),rgba(255,230,160,0.95))'
          : 'linear-gradient(135deg,rgba(255,252,235,0.9),rgba(255,240,180,0.88))',
        borderRadius: 22,
        padding: '18px 24px',
        border: '1.5px solid rgba(220,180,60,0.45)',
        boxShadow: hovered
          ? '0 8px 28px rgba(200,160,40,0.2)'
          : '0 4px 16px rgba(200,160,40,0.1)',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 16,
        transition: 'all 0.2s ease',
        transform: hovered ? 'translateY(-2px)' : 'translateY(0)',
        backdropFilter: 'blur(8px)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 40, height: 40, borderRadius: 12, background: 'linear-gradient(135deg,#ffd54f,#ffb300)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', boxShadow: '0 4px 12px rgba(200,150,0,0.3)', flexShrink: 0 }}>
          📋
        </div>
        <div>
          <div style={{ fontSize: '0.6rem', fontWeight: 800, letterSpacing: '0.14em', color: '#b08000', textTransform: 'uppercase', marginBottom: 2 }}>
            Weekly Project{project.week_label ? ` · ${project.week_label}` : ''}
          </div>
          <div style={{ fontSize: '1rem', fontWeight: 900, color: '#5a3a00' }}>{project.title}</div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#9a7000' }}>View task</span>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'rgba(200,150,0,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem', color: '#b08000' }}>▶</div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Card detail modal
───────────────────────────────────────────── */
function CardDetail({ card, onClose }: { card: Card; onClose: () => void }) {
  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, background: 'rgba(100,80,140,0.3)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '20px' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ background: 'linear-gradient(145deg,rgba(255,255,255,0.97),rgba(248,240,252,0.98))', borderRadius: 32, padding: '32px', maxWidth: 720, width: '90vw', boxShadow: '0 24px 64px rgba(160,80,200,0.18)', border: '2px solid rgba(255,255,255,0.9)', position: 'relative' }}
      >
        <button onClick={onClose} style={{ position: 'absolute', top: 16, right: 16, width: 32, height: 32, borderRadius: '50%', background: 'rgba(180,160,220,0.12)', border: 'none', fontSize: '1rem', cursor: 'pointer', color: '#9090c0' }}>✕</button>

        {/* Two-column table layout — card left, info right */}
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <colgroup>
            <col style={{ width: 200 }} />
            <col />
          </colgroup>
          <tbody>
            <tr>
              {/* Left column: card (scaled down) */}
              <td style={{ verticalAlign: 'top', paddingRight: 28 }}>
                <div style={{ transform: 'scale(0.78)', transformOrigin: 'top left', width: 'fit-content' }}>
                  {card.card_source === 'built' ? <BuiltCard card={card} /> : <PokeCard card={card} />}
                </div>
              </td>

              {/* Right column: text info */}
              <td style={{ verticalAlign: 'top' }}>
                <h2 style={{ fontSize: '1.4rem', fontWeight: 900, color: '#3040a0', marginBottom: 4, marginTop: 0 }}>{card.card_name}</h2>
                <div style={{ display: 'inline-block', padding: '3px 12px', borderRadius: 20, background: 'rgba(100,120,220,0.08)', border: '1px solid rgba(100,120,220,0.15)', fontSize: '0.65rem', fontWeight: 700, color: '#6070c0', marginBottom: 16, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
                  {RARITY_ICONS[card.rarity]} {card.rarity}
                </div>
                <p style={{ fontSize: '0.88rem', color: '#7080b0', fontStyle: 'italic', marginBottom: 20, lineHeight: 1.5 }}>"{card.description}"</p>
                {[
                  ['HP', card.hp], ['Type', card.type],
                  [card.stat1_name, card.stat1_val], [card.stat2_name, card.stat2_val], [card.stat3_name, card.stat3_val],
                  [card.move1_name, `${card.move1_dmg} dmg`], [card.move2_name, `${card.move2_dmg} dmg`],
                  ['Awarded', new Date(card.created_at).toLocaleDateString()],
                ].map(([k, v]) => (
                  <div key={String(k)} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(100,120,220,0.08)' }}>
                    <span style={{ fontSize: '0.72rem', color: '#9090c0', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{k}</span>
                    <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#3040a0' }}>{v}</span>
                  </div>
                ))}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Main dashboard
───────────────────────────────────────────── */
function StudentPage({ session, onSignOut }: { session: NonNullable<Session>; onSignOut: () => void }) {
  const [cards, setCards] = useState<Card[]>([]);
  const [detailCard, setDetailCard] = useState<Card | null>(null);
  const [studentName, setStudentName] = useState('Student');
  const [weeklyProject, setWeeklyProject] = useState<WeeklyProject | null>(null);
  const [showProject, setShowProject] = useState(false);
  const faceKey = `classcard_face_${session.user.id}`;
  const [facePixels, setFacePixelsRaw] = useState<string[] | null>(() => {
    try { const v = localStorage.getItem(faceKey); return v ? JSON.parse(v) : null; }
    catch { return null; }
  });
  const setFacePixels = (px: string[] | null) => {
    setFacePixelsRaw(px);
    try {
      if (px) localStorage.setItem(faceKey, JSON.stringify(px));
      else localStorage.removeItem(faceKey);
    } catch { /* ignore */ }
  };

  // Color index (0–3) — stored per student so they keep their chosen color
  const storageKey = `classcard_robot_knob_${session.user.id}`;
  const [knob, setKnobRaw] = useState<number>(() => {
    try { const v = localStorage.getItem(storageKey); return v !== null ? Math.min(3, Math.max(0, parseInt(v, 10) || 0)) : 0; }
    catch { return 0; }
  });

  const setKnob = (v: number) => {
    setKnobRaw(v);
    try { localStorage.setItem(storageKey, String(v)); } catch { /* ignore */ }
  };

  const robotColor = COLOR_THEMES[knob % COLOR_THEMES.length];

  const loadCards = useCallback(async () => {
    try {
      const profile = session.profile;
      setStudentName(profile.name || 'Student');
      let studentId = profile.student_id;
      if (!studentId) {
        const { data } = await (await import('../lib/supabase')).sb
          .from('students').select('id').eq('auth_user_id', session.user.id).maybeSingle();
        if (data) studentId = data.id;
      }
      if (studentId) {
        setCards(await Dashboard.getStudentCards(studentId));
        // Fetch teacher's weekly project
        const { data: studentRow } = await sb.from('students').select('teacher_id').eq('id', studentId).maybeSingle();
        if (studentRow?.teacher_id) {
          const { data: proj } = await sb
            .from('weekly_projects')
            .select('*')
            .eq('teacher_id', studentRow.teacher_id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();
          if (proj) setWeeklyProject(proj as WeeklyProject);
        }
      }
    } catch { /* silent */ }
  }, [session]);

  useEffect(() => { loadCards(); }, [loadCards]);

  const score = useMemo(() => rarityScore(cards), [cards]);
  const level = Math.max(1, Math.floor(score / 500) + 1);
  const xp = score % 500;

  const firstName = studentName.split(' ')[0];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap');
        .sd-page * { font-family: 'Nunito', 'Segoe UI', sans-serif !important; }
        .sd-page ::-webkit-scrollbar { height: 4px; }
        .sd-page ::-webkit-scrollbar-track { background: rgba(200,180,220,0.1); border-radius: 10px; }
        .sd-page ::-webkit-scrollbar-thumb { background: rgba(160,140,200,0.3); border-radius: 10px; }
      `}</style>

      <div
        className="sd-page"
        style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #fce4ec 0%, #f3e5f5 30%, #e8eaf6 60%, #e1f5fe 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px',
        }}
      >
        {/* Outer container */}
        <div style={{
          width: '100%',
          maxWidth: 1160,
          background: 'rgba(255,255,255,0.45)',
          borderRadius: 40,
          padding: '28px 32px',
          boxShadow: '0 20px 80px rgba(180,120,220,0.12), 0 4px 24px rgba(200,160,240,0.08)',
          border: '2px solid rgba(255,255,255,0.8)',
          backdropFilter: 'blur(12px)',
          display: 'flex',
          flexDirection: 'column',
          gap: 20,
        }}>

          {/* ── TOP ROW ── */}
          <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>

            {/* Welcome + Robot */}
            <div style={{ display: 'flex', gap: 20, alignItems: 'flex-end', flexShrink: 0 }}>
              <div>
                <h1 style={{ fontSize: 'clamp(1.6rem, 3vw, 2.2rem)', fontWeight: 900, color: '#2030a0', margin: 0, lineHeight: 1.1 }}>
                  Hey {firstName}!
                </h1>
                <p style={{ fontSize: '0.85rem', color: '#8090c0', margin: '6px 0 0', fontWeight: 600 }}>
                  You've collected {cards.length} card{cards.length !== 1 ? 's' : ''}
                </p>
                <div style={{ marginTop: 16 }}>
                  <RobotAvatar level={level} xp={xp} xpMax={500} color={robotColor} facePixels={facePixels} />
                </div>
              </div>
            </div>

            {/* Signal panel + Pixel editor stacked */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <SignalPanel knob={knob} onKnobChange={setKnob} />
              <PixelEditor
                waveColor={COLOR_THEMES[knob % COLOR_THEMES.length].wave}
                onSend={setFacePixels}
                onReset={() => setFacePixels(null)}
              />
            </div>

            {/* Stats panel */}
            <StatsPanel
              total={cards.length}
              rarityScoreVal={score}
              onSignOut={onSignOut}
              studentName={studentName}
            />
          </div>

          {/* ── WEEKLY PROJECT BANNER ── */}
          {weeklyProject && (
            <WeeklyProjectBanner project={weeklyProject} onClick={() => setShowProject(true)} />
          )}

          {/* ── CARD CAROUSEL ── */}
          <CardCarousel cards={cards} onCardClick={setDetailCard} />
        </div>
      </div>

      {detailCard && <CardDetail card={detailCard} onClose={() => setDetailCard(null)} />}
      {showProject && weeklyProject && (
        <WeeklyProjectModal project={weeklyProject} onClose={() => setShowProject(false)} />
      )}
    </>
  );
}

export default StudentPage;
